<?

$email_to ="innocenttimes@gmail.com,prashant@optimist.co.in,design@optimist.co.in,supriya@ptimist.co.in"; 
$email_subject = "Enquiry Form "; // email subject line
$thankyou = "../home.html"; // thank you page

?>



