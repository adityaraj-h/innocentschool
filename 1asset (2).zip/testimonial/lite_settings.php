<?

$email_to ="innocenttimes@gmail.com,design@optimist.co.in,prashant@optimist.co.in "; 
$email_subject = "Testimonials "; // email subject line
$thankyou = "../thank-you.html"; // thank you page

?>



