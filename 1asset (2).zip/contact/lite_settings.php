<?

$email_to ="design@optimist.co.in,innocenttimes@gmail.com,prashant@optimist.co.in,supriya@optimist.co.in"; 
$email_subject = "Enquiry Form "; // email subject line
$thankyou = "../thanks.html"; // thank you page

?>



