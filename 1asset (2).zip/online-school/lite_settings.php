<?

$email_to ="innocenttimes@gmail.com,design@optimist.co.in,prashant@optimist.co.in,supriya@optimist.co.in "; 
$email_subject = "Survey "; // email subject line
$thankyou = "../thank-survey.html"; // thank you page

?>



